define([], function() {
  'use strict';

  var DataDescriptionModule = function DataDescriptionModule() {};

  return DataDescriptionModule;
});
