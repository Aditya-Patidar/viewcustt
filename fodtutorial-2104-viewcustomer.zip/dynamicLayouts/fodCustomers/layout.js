define([], function() {
  'use strict';

  var LayoutModule = function LayoutModule() {};

  return LayoutModule;
});
